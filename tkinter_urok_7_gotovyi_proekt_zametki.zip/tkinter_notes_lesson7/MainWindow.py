import tkinter as tk
from Methods import Methods
from Note import Note
from TextEditWindow import TextEditWindow


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.add_button = None
        self.frame_notes = None
        self.__files = []
        self.__name = "Приложение для заметок"

    def start(self):
        self.title(self.__name)
        self.geometry("800x600")

        header = tk.Label(self, text="МОИ ЗАМЕТКИ", font=("Arial", 20, "bold"))
        header.pack(pady=12)

        # Общий контейнер для карточек заметок.
        self.frame_notes = tk.Frame(self, bg="#f2f4f8")
        self.frame_notes.pack(padx=12, pady=8, fill="both", expand=True)

        self.add_button = tk.Button(
            self,
            text="+ Добавить заметку",
            font=("Arial", 13),
            command=self.create_note_card
        )
        self.add_button.pack(side="bottom", pady=12)

        self.refresh_notes_list()
        self.show_note_card()
        self.mainloop()

    def refresh_notes_list(self):
        # Убираем старые карточки, чтобы не было повторов.
        for widget in self.frame_notes.winfo_children():
            widget.destroy()

        self.__files.clear()
        for note_name in Methods.get_note_list():
            self.add_note_to_note_list(Note(note_name))

    def add_note_to_note_list(self, note: Note):
        self.__files.append(note)

    def show_note_card(self):
        if not self.__files:
            tk.Label(
                self.frame_notes,
                text="Пока нет заметок. Нажми «+ Добавить заметку»",
                bg="#f2f4f8", font=("Arial", 12)
            ).pack(pady=30)

        for note in self.__files:
            self.add_note_card(note)

    def add_note_card(self, note: Note):
        # Маленькая белая карточка с названием и кнопками.
        card = tk.Frame(self.frame_notes, bg="white", bd=1, relief="solid")
        card.pack(padx=10, pady=5, fill="x")

        title = tk.Label(card, text=note.get_filename(), bg="white", font=("Arial", 12))
        title.pack(side="left", padx=10, pady=12)

        edit_button = tk.Button(
            card, text="Редактировать", command=lambda: self.edit_note(note)
        )
        edit_button.pack(side="right", padx=6)

        delete_button = tk.Button(
            card, text="Удалить", command=lambda: self.delete_note(note)
        )
        delete_button.pack(side="right", padx=6)

    def edit_note(self, note: Note):
        edit_window = TextEditWindow(self, note)
        edit_window.grab_set()

    def delete_note(self, note: Note):
        deleted = note.delete_note()
        if deleted:
            self.refresh_notes_list()
            self.show_note_card()

    def create_note_card(self):
        created = Note.create_note()
        if created is not None:
            self.refresh_notes_list()
            self.show_note_card()
