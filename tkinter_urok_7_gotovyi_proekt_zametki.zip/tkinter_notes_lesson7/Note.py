import os
import uuid
from pathlib import Path
from tkinter import simpledialog, messagebox

# Все .note-файлы будут находиться в отдельной папке notes.
NOTES_DIR = Path(__file__).resolve().parent / "notes"
NOTES_DIR.mkdir(exist_ok=True)


class Note:
    def __init__(self, filename):
        self.__filename = filename

    def get_filename(self):
        return self.__filename

    def get_note_text(self):
        """Прочитать текст заметки."""
        path = NOTES_DIR / self.__filename
        with open(path, "r", encoding="utf-8") as file:
            return file.read()

    def save_note(self, new_text):
        """Сохранить изменённый текст заметки."""
        path = NOTES_DIR / self.__filename
        with open(path, "w", encoding="utf-8") as file:
            file.write(new_text)
        messagebox.showinfo("Успех", "Заметка сохранена!")

    def delete_note(self):
        """Удалить заметку только после подтверждения пользователя."""
        answer = messagebox.askyesno(
            "Удалить заметку?", f"Точно удалить «{self.__filename}»?"
        )
        if answer:
            os.remove(NOTES_DIR / self.__filename)
            return True
        return False

    @staticmethod
    def create_note():
        """Спросить имя и создать новый пустой файл .note."""
        name = simpledialog.askstring("Новая заметка", "Введите имя заметки:")

        if name is None:  # Пользователь нажал «Отмена»
            return None

        name = name.strip()
        if name == "":
            # Генерируем короткое случайное имя, если поле было пустым.
            name = "note-" + uuid.uuid4().hex[:8]

        if name.lower().endswith(".note"):
            name = name[:-5]

        # Эти символы запрещены в именах файлов во многих системах.
        if not name or name in (".", "..") or any(ch in name for ch in '\\/:*?"<>|'):
            messagebox.showerror("Ошибка", "Недопустимое имя заметки")
            return None

        filename = name + ".note"
        path = NOTES_DIR / filename

        if path.exists():
            messagebox.showwarning("Внимание", "Заметка с таким именем уже есть!")
            return None

        # Режим x создаёт файл, но не перезаписывает существующий.
        try:
            with open(path, "x", encoding="utf-8"):
                pass
        except FileExistsError:
            messagebox.showwarning("Внимание", "Заметка с таким именем уже есть!")
            return None

        messagebox.showinfo("Успех", "Заметка создана!")
        return Note(filename)
