import os
from Note import NOTES_DIR


class Methods:
    @staticmethod
    def get_note_list():
        return sorted([
            filename
            for filename in os.listdir(NOTES_DIR)
            if filename.endswith(".note")
            and (NOTES_DIR / filename).is_file()
        ])
