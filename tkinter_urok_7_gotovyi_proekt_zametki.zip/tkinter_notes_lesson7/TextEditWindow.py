import tkinter as tk
from tkinter import scrolledtext
from Note import Note


class TextEditWindow(tk.Toplevel):
    def __init__(self, parent, note: Note):
        super().__init__(parent)
        self.note = note
        self.geometry("700x500")
        self.title(note.get_filename())

        self.text_area = scrolledtext.ScrolledText(
            self, wrap=tk.WORD, font=("Arial", 12)
        )
        self.text_area.pack(fill="both", expand=True, padx=10, pady=10)
        self.text_area.insert("1.0", note.get_note_text())

        self.button = tk.Button(self, text="Сохранить", command=self.save_note)
        self.button.pack(pady=8)

    def save_note(self):
        new_text = self.text_area.get("1.0", "end-1c")
        self.note.save_note(new_text)
        self.destroy()
