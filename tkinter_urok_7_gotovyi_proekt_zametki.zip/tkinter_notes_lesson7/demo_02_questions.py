import tkinter as tk
from tkinter import messagebox, simpledialog

root = tk.Tk()
root.title("Программа задаёт вопросы")
root.geometry("460x240")

answer_label = tk.Label(root, text="Ответ появится здесь", font=("Arial", 12))
answer_label.pack(pady=25)


def ask_delete():
    answer = messagebox.askyesno("Удаление", "Удалить учебную заметку?")
    if answer:
        answer_label.config(text="Ответ: ДА (True)")
    else:
        answer_label.config(text="Ответ: НЕТ (False)")


def ask_name():
    name = simpledialog.askstring("Новая заметка", "Как назовём заметку?")
    if name is None:
        answer_label.config(text="Нажата кнопка «Отмена»")
    elif name == "":
        answer_label.config(text="Нажали ОК, но строка пустая")
    else:
        answer_label.config(text=f"Имя: {name}")


tk.Button(root, text="Спросить: удалить?", command=ask_delete).pack(pady=5)
tk.Button(root, text="Спросить: название?", command=ask_name).pack(pady=5)
root.mainloop()
