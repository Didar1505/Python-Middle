import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.title("Три вида сообщений")
root.geometry("420x260")


def show_success():
    messagebox.showinfo("Информация", "Заметка сохранена!")


def show_warning():
    messagebox.showwarning("Внимание", "Сначала придумай название!")


def show_error():
    messagebox.showerror("Ошибка", "Не удалось выполнить действие")


tk.Label(root, text="Нажми на каждую кнопку", font=("Arial", 14)).pack(pady=12)
tk.Button(root, text="Информация", command=show_success).pack(pady=5)
tk.Button(root, text="Предупреждение", command=show_warning).pack(pady=5)
tk.Button(root, text="Ошибка", command=show_error).pack(pady=5)
root.mainloop()
