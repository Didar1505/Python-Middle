import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
from AboutWindow import About


class MainWindow(tk.Tk):
    """Главное окно текстового редактора."""

    def __init__(self):
        super().__init__()
        self.title("Блокнот")
        self.geometry("800x600")
        self._filepath = None  # Пока пользователь не выбрал файл

        self.edit_text = scrolledtext.ScrolledText(
            self, width=96, height=37, wrap="word", font=("Arial", 12)
        )
        self._create_menu()
        self.edit_text.pack(fill="both", expand=True, padx=8, pady=8)

    def _create_menu(self):
        self._menu = tk.Menu(self, tearoff=0)
        self._menu.add_command(label="Открыть файл", command=self._open_file)
        self._menu.add_command(label="Сохранить файл как", command=self._save_file_as)
        self._menu.add_command(label="Сохранить файл", command=self._save_file)
        self._menu.add_command(label="О программе", command=self._open_about)
        self.config(menu=self._menu)

    def _open_file(self):
        path = filedialog.askopenfilename(
            title="Выберите текстовый файл",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
        )
        if not path:  # Нажали «Отмена»
            return

        try:
            with open(path, "r", encoding="utf-8") as file:
                text = file.read()
        except (OSError, UnicodeError) as error:
            messagebox.showerror("Ошибка открытия", str(error))
            return

        self.edit_text.delete("1.0", tk.END)
        self.edit_text.insert("1.0", text)
        self._filepath = path
        self.title(f"Блокнот — {path}")

    def _save_file_as(self):
        path = filedialog.asksaveasfilename(
            title="Сохранить файл как",
            defaultextension=".txt",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
        )
        if not path:  # Нажали «Отмена»
            return
        previous_path = self._filepath
        self._filepath = path
        if not self._write_file():
            self._filepath = previous_path

    def _save_file(self):
        if self._filepath is None:
            self._save_file_as()  # Первое сохранение: просим имя файла
            return
        self._write_file()

    def _write_file(self):
        text = self.edit_text.get("1.0", "end-1c")
        try:
            with open(self._filepath, "w", encoding="utf-8") as file:
                file.write(text)
        except OSError as error:
            messagebox.showerror("Ошибка сохранения", str(error))
            return False
        self.title(f"Блокнот — {self._filepath}")
        return True

    def _open_about(self):
        about = About(self)
        about.grab_set()  # Пока окно открыто, пользователь работает с ним
