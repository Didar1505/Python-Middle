import tkinter as tk


class About(tk.Toplevel):
    """Небольшое окно с информацией о нашей программе."""

    def __init__(self, parent):
        super().__init__(parent)
        self.title("О программе")
        self.geometry("300x160")
        self.resizable(False, False)

        label = tk.Label(self, text="Блокнот на Python\nВерсия: 1.0", font=("Arial", 13))
        label.pack(padx=20, pady=22)

        button = tk.Button(self, text="Закрыть", command=self.destroy)
        button.pack(pady=5, ipadx=10, ipady=3)
